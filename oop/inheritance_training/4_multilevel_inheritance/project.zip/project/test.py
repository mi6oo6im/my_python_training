from project.sports_car import SportsCar


toyota = SportsCar()
print(toyota.drive())
print(toyota.move())
print(toyota.race())